<?php
class Model{
	
	public $str="hejka";

}